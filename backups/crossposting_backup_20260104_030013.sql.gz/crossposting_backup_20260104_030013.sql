--
-- PostgreSQL database dump
--

\restrict y548af1VOusN5pGEb4O8Eddv4yvPkkIq9BYu78XSAAnsuPbfOhYBqo4WDFBNEyl

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_sessions (
    id bigint NOT NULL,
    admin_id bigint NOT NULL,
    token character varying(512) NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: admin_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_sessions_id_seq OWNED BY public.admin_sessions.id;


--
-- Name: admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admins (
    id bigint NOT NULL,
    username character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    email character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    last_login timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    action character varying NOT NULL,
    entity_type character varying NOT NULL,
    entity_id bigint NOT NULL,
    details json,
    created_at timestamp without time zone NOT NULL
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: crossposting_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.crossposting_links (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    telegram_channel_id bigint NOT NULL,
    max_channel_id bigint NOT NULL,
    is_enabled boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    subscription_status character varying(50) DEFAULT 'free_trial'::character varying NOT NULL,
    free_trial_end_date timestamp without time zone,
    subscription_end_date timestamp without time zone,
    is_first_link boolean DEFAULT false NOT NULL,
    last_payment_date timestamp without time zone,
    payment_id character varying(255),
    payment_status character varying(50),
    yookassa_payment_id character varying(255)
);


--
-- Name: crossposting_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.crossposting_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: crossposting_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.crossposting_links_id_seq OWNED BY public.crossposting_links.id;


--
-- Name: failed_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_messages (
    id bigint NOT NULL,
    crossposting_link_id bigint NOT NULL,
    telegram_message_id bigint NOT NULL,
    error_message text NOT NULL,
    retry_count integer NOT NULL,
    last_retry_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    resolved_at timestamp without time zone
);


--
-- Name: failed_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.failed_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: failed_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.failed_messages_id_seq OWNED BY public.failed_messages.id;


--
-- Name: max_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.max_channels (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    channel_id character varying NOT NULL,
    channel_username character varying,
    channel_title character varying NOT NULL,
    bot_added_at timestamp without time zone NOT NULL,
    is_active boolean NOT NULL
);


--
-- Name: max_channels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.max_channels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: max_channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.max_channels_id_seq OWNED BY public.max_channels.id;


--
-- Name: messages_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages_log (
    id bigint NOT NULL,
    crossposting_link_id bigint NOT NULL,
    telegram_message_id bigint NOT NULL,
    max_message_id character varying,
    status character varying NOT NULL,
    error_message text,
    message_type character varying,
    file_size bigint,
    processing_time_ms integer,
    created_at timestamp without time zone NOT NULL,
    sent_at timestamp without time zone
);


--
-- Name: messages_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_log_id_seq OWNED BY public.messages_log.id;


--
-- Name: telegram_channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.telegram_channels (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    channel_username character varying,
    channel_title character varying NOT NULL,
    bot_added_at timestamp without time zone NOT NULL,
    is_active boolean NOT NULL
);


--
-- Name: telegram_channels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.telegram_channels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: telegram_channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.telegram_channels_id_seq OWNED BY public.telegram_channels.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    telegram_user_id bigint NOT NULL,
    telegram_username character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_vip boolean DEFAULT false NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: admin_sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_sessions ALTER COLUMN id SET DEFAULT nextval('public.admin_sessions_id_seq'::regclass);


--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: crossposting_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crossposting_links ALTER COLUMN id SET DEFAULT nextval('public.crossposting_links_id_seq'::regclass);


--
-- Name: failed_messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_messages ALTER COLUMN id SET DEFAULT nextval('public.failed_messages_id_seq'::regclass);


--
-- Name: max_channels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.max_channels ALTER COLUMN id SET DEFAULT nextval('public.max_channels_id_seq'::regclass);


--
-- Name: messages_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages_log ALTER COLUMN id SET DEFAULT nextval('public.messages_log_id_seq'::regclass);


--
-- Name: telegram_channels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_channels ALTER COLUMN id SET DEFAULT nextval('public.telegram_channels_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: admin_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admin_sessions (id, admin_id, token, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.admins (id, username, password_hash, email, is_active, last_login, created_at, updated_at) FROM stdin;
1	admin	$2b$12$c5di0/tZKm13TJopfNRuFuQ3jpQqF5TJ8trU4Y2SJOsSlNxBnWu96	\N	t	2026-01-03 23:47:41.179632	2026-01-03 21:47:54.885873	2026-01-04 02:47:40.911162
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
002_add_subscription_fields
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, user_id, action, entity_type, entity_id, details, created_at) FROM stdin;
71	63	create_link	crossposting_link	66	{"telegram_channel_id": 61, "max_channel_id": 66}	2026-01-02 17:48:18.459074
72	63	delete_link	crossposting_link	66	null	2026-01-02 17:52:09.938335
73	63	create_link	crossposting_link	67	{"telegram_channel_id": 61, "max_channel_id": 67}	2026-01-02 17:52:32.186151
74	63	delete_link	crossposting_link	67	null	2026-01-02 17:55:27.387493
75	63	create_link	crossposting_link	68	{"telegram_channel_id": 61, "max_channel_id": 68}	2026-01-02 17:56:14.738695
76	64	create_link	crossposting_link	69	{"telegram_channel_id": 62, "max_channel_id": 69}	2026-01-02 17:57:30.920409
77	64	delete_link	crossposting_link	69	null	2026-01-02 18:05:12.231299
78	64	delete_link	crossposting_link	69	null	2026-01-02 18:05:12.300367
79	64	create_link	crossposting_link	70	{"telegram_channel_id": 62, "max_channel_id": 70}	2026-01-02 18:05:42.201855
80	64	delete_link	crossposting_link	70	null	2026-01-02 18:12:50.317837
81	64	create_link	crossposting_link	71	{"telegram_channel_id": 62, "max_channel_id": 71}	2026-01-02 18:13:09.373655
82	64	delete_link	crossposting_link	71	null	2026-01-02 18:18:21.978642
83	64	create_link	crossposting_link	72	{"telegram_channel_id": 62, "max_channel_id": 72}	2026-01-02 18:18:45.864943
\.


--
-- Data for Name: crossposting_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.crossposting_links (id, user_id, telegram_channel_id, max_channel_id, is_enabled, created_at, updated_at, subscription_status, free_trial_end_date, subscription_end_date, is_first_link, last_payment_date, payment_id, payment_status, yookassa_payment_id) FROM stdin;
68	63	61	68	t	2026-01-02 17:56:14.7285	2026-01-02 17:59:53.181965	free_trial	\N	\N	f	\N	\N	\N	\N
72	64	62	72	t	2026-01-02 18:18:45.804198	2026-01-02 18:23:09.23559	free_trial	\N	\N	f	\N	\N	\N	\N
\.


--
-- Data for Name: failed_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_messages (id, crossposting_link_id, telegram_message_id, error_message, retry_count, last_retry_at, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: max_channels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.max_channels (id, user_id, channel_id, channel_username, channel_title, bot_added_at, is_active) FROM stdin;
68	63	-70002399365886	id9725096017_biz	Никита Петренко	2026-01-02 17:56:14.715605	t
72	64	-69290578698370	annabellis79	Анна Беллис	2026-01-02 18:18:45.785801	t
\.


--
-- Data for Name: messages_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages_log (id, crossposting_link_id, telegram_message_id, max_message_id, status, error_message, message_type, file_size, processing_time_ms, created_at, sent_at) FROM stdin;
1144	68	150	\N	pending	\N	document	\N	\N	2026-01-02 17:59:26.409342	\N
1146	68	152	\N	pending	\N	document	\N	\N	2026-01-02 17:59:30.724465	\N
1147	68	155	\N	pending	\N	sticker	\N	\N	2026-01-02 17:59:34.731417	\N
1148	68	156	\N	pending	\N	video	\N	\N	2026-01-02 17:59:37.291515	\N
1150	68	160	\N	pending	\N	video	\N	\N	2026-01-02 17:59:49.138417	\N
1152	68	161	\N	pending	\N	text	\N	\N	2026-01-02 17:59:52.929985	\N
1197	72	475	\N	pending	\N	photo	\N	\N	2026-01-02 18:18:54.052015	\N
1198	72	477	\N	pending	\N	document	\N	\N	2026-01-02 18:19:01.375315	\N
1199	72	478	\N	pending	\N	video	\N	\N	2026-01-02 18:19:07.988688	\N
1200	72	480	\N	pending	\N	video	\N	\N	2026-01-02 18:19:13.254762	\N
1201	72	481	\N	pending	\N	video	\N	\N	2026-01-02 18:19:18.234973	\N
1202	72	483	\N	pending	\N	video	\N	\N	2026-01-02 18:19:23.763985	\N
1203	72	484	\N	pending	\N	video	\N	\N	2026-01-02 18:19:30.167756	\N
1204	72	488	\N	pending	\N	video	\N	\N	2026-01-02 18:19:37.12907	\N
1205	72	489	\N	pending	\N	video	\N	\N	2026-01-02 18:19:42.898874	\N
1206	72	490	\N	pending	\N	video	\N	\N	2026-01-02 18:19:48.053046	\N
1207	72	492	\N	success	\N	video	\N	\N	2026-01-02 18:19:56.168923	2026-01-02 18:20:01.560681
1208	72	491	\N	success	\N	video	\N	\N	2026-01-02 18:19:56.177003	2026-01-02 18:20:01.567254
1209	72	494	\N	pending	\N	video	\N	\N	2026-01-02 18:20:02.566686	\N
1210	72	495	\N	pending	\N	video	\N	\N	2026-01-02 18:20:07.335102	\N
1211	72	497	\N	pending	\N	video	\N	\N	2026-01-02 18:20:15.747216	\N
1212	72	498	\N	pending	\N	video	\N	\N	2026-01-02 18:20:23.693756	\N
1213	72	499	\N	pending	\N	video	\N	\N	2026-01-02 18:20:30.612986	\N
1214	72	500	\N	pending	\N	video	\N	\N	2026-01-02 18:20:36.559051	\N
1215	72	501	\N	pending	\N	video	\N	\N	2026-01-02 18:20:43.318671	\N
1216	72	502	\N	pending	\N	video	\N	\N	2026-01-02 18:20:49.003897	\N
1217	72	503	\N	pending	\N	photo	\N	\N	2026-01-02 18:20:53.716709	\N
1218	72	504	\N	pending	\N	video	\N	\N	2026-01-02 18:20:56.925779	\N
1219	72	505	\N	pending	\N	video	\N	\N	2026-01-02 18:21:00.881427	\N
1220	72	506	\N	pending	\N	text	\N	\N	2026-01-02 18:21:05.014915	\N
1221	72	507	\N	pending	\N	video	\N	\N	2026-01-02 18:21:07.386839	\N
1222	72	510	\N	pending	\N	video	\N	\N	2026-01-02 18:21:12.907102	\N
1223	72	509	\N	pending	\N	photo	\N	\N	2026-01-02 18:21:12.914898	\N
1224	72	511	\N	pending	\N	text	\N	\N	2026-01-02 18:21:19.324826	\N
1225	72	512	\N	pending	\N	video	\N	\N	2026-01-02 18:21:21.419192	\N
1226	72	513	\N	pending	\N	text	\N	\N	2026-01-02 18:21:26.652533	\N
1227	72	514	\N	pending	\N	photo	\N	\N	2026-01-02 18:21:27.587745	\N
1121	68	139	\N	pending	\N	text	\N	\N	2026-01-02 17:57:56.122782	\N
1122	68	140	\N	pending	\N	text	\N	\N	2026-01-02 17:57:56.472158	\N
1123	68	141	\N	pending	\N	text	\N	\N	2026-01-02 17:57:56.749402	\N
1228	72	515	\N	pending	\N	photo	\N	\N	2026-01-02 18:21:30.879354	\N
1125	68	142	\N	pending	\N	photo	\N	\N	2026-01-02 17:57:57.783697	\N
1229	72	516	\N	pending	\N	photo	\N	\N	2026-01-02 18:21:34.081549	\N
1126	68	144	\N	success	\N	photo	\N	\N	2026-01-02 17:58:17.129691	2026-01-02 17:58:35.039633
1127	68	143	\N	success	\N	photo	\N	\N	2026-01-02 17:58:17.14436	2026-01-02 17:58:35.043995
1230	72	521	\N	success	\N	photo	\N	\N	2026-01-02 18:21:40.067651	2026-01-02 18:21:43.722196
1231	72	520	\N	success	\N	photo	\N	\N	2026-01-02 18:21:40.075899	2026-01-02 18:21:43.727801
1134	68	145	\N	pending	\N	video	\N	\N	2026-01-02 17:58:53.269102	\N
1232	72	519	\N	success	\N	photo	\N	\N	2026-01-02 18:21:40.084116	2026-01-02 18:21:43.730528
1233	72	518	\N	success	\N	photo	\N	\N	2026-01-02 18:21:40.091008	2026-01-02 18:21:43.732929
1234	72	517	\N	success	\N	photo	\N	\N	2026-01-02 18:21:40.096625	2026-01-02 18:21:43.735535
1235	72	523	\N	pending	\N	photo	\N	\N	2026-01-02 18:21:44.547724	\N
1236	72	524	\N	pending	\N	photo	\N	\N	2026-01-02 18:21:47.86207	\N
1137	68	147	\N	success	\N	video	\N	\N	2026-01-02 17:58:59.739167	2026-01-02 17:59:15.511767
1138	68	146	\N	success	\N	video	\N	\N	2026-01-02 17:58:59.748064	2026-01-02 17:59:15.515615
1237	72	525	\N	pending	\N	photo	\N	\N	2026-01-02 18:21:50.917233	\N
1141	68	149	\N	pending	\N	photo	\N	\N	2026-01-02 17:59:19.503287	\N
1142	68	148	\N	pending	\N	video	\N	\N	2026-01-02 17:59:19.509438	\N
1238	72	526	\N	pending	\N	photo	\N	\N	2026-01-02 18:21:54.064736	\N
1239	72	540	\N	success	\N	photo	\N	\N	2026-01-02 18:22:00.115833	2026-01-02 18:22:03.772887
1240	72	539	\N	success	\N	photo	\N	\N	2026-01-02 18:22:00.12503	2026-01-02 18:22:03.781846
1241	72	538	\N	success	\N	photo	\N	\N	2026-01-02 18:22:00.132728	2026-01-02 18:22:03.790647
1242	72	537	\N	success	\N	photo	\N	\N	2026-01-02 18:22:00.144084	2026-01-02 18:22:03.798918
1243	72	536	\N	success	\N	photo	\N	\N	2026-01-02 18:22:00.151902	2026-01-02 18:22:03.807263
1244	72	547	\N	success	\N	photo	\N	\N	2026-01-02 18:22:10.204838	2026-01-02 18:22:14.994389
1245	72	546	\N	success	\N	photo	\N	\N	2026-01-02 18:22:10.212261	2026-01-02 18:22:15.005946
1246	72	545	\N	success	\N	photo	\N	\N	2026-01-02 18:22:10.217987	2026-01-02 18:22:15.008942
1247	72	544	\N	success	\N	photo	\N	\N	2026-01-02 18:22:10.224097	2026-01-02 18:22:15.011818
1248	72	543	\N	success	\N	photo	\N	\N	2026-01-02 18:22:10.22997	2026-01-02 18:22:15.014473
1249	72	542	\N	success	\N	photo	\N	\N	2026-01-02 18:22:10.251992	2026-01-02 18:22:15.01716
1250	72	541	\N	success	\N	photo	\N	\N	2026-01-02 18:22:10.257909	2026-01-02 18:22:15.019515
1251	72	550	\N	success	\N	photo	\N	\N	2026-01-02 18:22:10.264136	2026-01-02 18:22:15.021848
1252	72	549	\N	success	\N	photo	\N	\N	2026-01-02 18:22:10.270471	2026-01-02 18:22:15.024186
1253	72	554	\N	success	\N	photo	\N	\N	2026-01-02 18:22:17.474378	2026-01-02 18:22:20.623749
1254	72	553	\N	success	\N	photo	\N	\N	2026-01-02 18:22:17.500767	2026-01-02 18:22:20.627783
1255	72	552	\N	success	\N	photo	\N	\N	2026-01-02 18:22:17.508031	2026-01-02 18:22:20.630098
1256	72	560	\N	pending	\N	video	\N	\N	2026-01-02 18:22:22.450697	\N
1257	72	561	\N	success	\N	photo	\N	\N	2026-01-02 18:22:27.583085	2026-01-02 18:22:30.501954
1258	72	562	\N	success	\N	photo	\N	\N	2026-01-02 18:22:27.60027	2026-01-02 18:22:30.506504
1259	72	566	\N	success	\N	photo	\N	\N	2026-01-02 18:22:33.755914	2026-01-02 18:22:37.275993
1260	72	565	\N	success	\N	photo	\N	\N	2026-01-02 18:22:33.762014	2026-01-02 18:22:37.280714
1261	72	564	\N	success	\N	photo	\N	\N	2026-01-02 18:22:33.768451	2026-01-02 18:22:37.283317
1262	72	567	\N	success	\N	photo	\N	\N	2026-01-02 18:22:33.77427	2026-01-02 18:22:37.285753
1263	72	571	\N	success	\N	photo	\N	\N	2026-01-02 18:22:40.602011	2026-01-02 18:22:44.027804
1264	72	570	\N	success	\N	photo	\N	\N	2026-01-02 18:22:40.608111	2026-01-02 18:22:44.031745
1265	72	569	\N	success	\N	photo	\N	\N	2026-01-02 18:22:40.61347	2026-01-02 18:22:44.034261
1266	72	568	\N	success	\N	photo	\N	\N	2026-01-02 18:22:40.618419	2026-01-02 18:22:44.036502
1267	72	577	\N	success	\N	photo	\N	\N	2026-01-02 18:22:50.184943	2026-01-02 18:22:54.613194
1268	72	576	\N	success	\N	photo	\N	\N	2026-01-02 18:22:50.194869	2026-01-02 18:22:54.617323
1269	72	575	\N	success	\N	photo	\N	\N	2026-01-02 18:22:50.201012	2026-01-02 18:22:54.619701
1270	72	574	\N	success	\N	photo	\N	\N	2026-01-02 18:22:50.208656	2026-01-02 18:22:54.621795
1271	72	573	\N	success	\N	photo	\N	\N	2026-01-02 18:22:50.215328	2026-01-02 18:22:54.624162
1272	72	572	\N	success	\N	photo	\N	\N	2026-01-02 18:22:50.22328	2026-01-02 18:22:54.626163
1273	72	579	\N	success	\N	photo	\N	\N	2026-01-02 18:22:50.231228	2026-01-02 18:22:54.62829
1274	72	578	\N	success	\N	photo	\N	\N	2026-01-02 18:22:50.238983	2026-01-02 18:22:54.630399
1275	72	587	\N	success	\N	photo	\N	\N	2026-01-02 18:23:01.490873	2026-01-02 18:23:05.998454
1276	72	586	\N	success	\N	photo	\N	\N	2026-01-02 18:23:01.517297	2026-01-02 18:23:06.002277
1277	72	585	\N	success	\N	photo	\N	\N	2026-01-02 18:23:01.523883	2026-01-02 18:23:06.00601
1278	72	584	\N	success	\N	photo	\N	\N	2026-01-02 18:23:01.529528	2026-01-02 18:23:06.010063
1279	72	583	\N	success	\N	photo	\N	\N	2026-01-02 18:23:01.534733	2026-01-02 18:23:06.013011
1280	72	582	\N	success	\N	photo	\N	\N	2026-01-02 18:23:01.540448	2026-01-02 18:23:06.015881
1281	72	581	\N	success	\N	photo	\N	\N	2026-01-02 18:23:01.546807	2026-01-02 18:23:06.018709
1282	72	580	\N	success	\N	photo	\N	\N	2026-01-02 18:23:01.552766	2026-01-02 18:23:06.021475
1283	72	588	\N	pending	\N	photo	\N	\N	2026-01-02 18:23:06.807399	\N
1284	68	163	\N	pending	\N	text	\N	\N	2026-01-02 19:08:24.616457	\N
1285	68	165	\N	pending	\N	text	\N	\N	2026-01-03 16:41:16.050356	\N
1286	68	166	\N	pending	\N	text	\N	\N	2026-01-03 21:00:48.523036	\N
\.


--
-- Data for Name: telegram_channels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.telegram_channels (id, user_id, channel_id, channel_username, channel_title, bot_added_at, is_active) FROM stdin;
61	63	-1003553081323	srazuum	Сразуум - кросспостинг Telegram/MAX	2026-01-02 17:48:12.217216	t
62	64	-1001695702955	annabellis79	Анна Беллис	2026-01-02 17:57:20.686321	t
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, telegram_user_id, telegram_username, created_at, updated_at, is_vip) FROM stdin;
63	46701395	nikitapetrenko	2026-01-02 17:48:02.753673	2026-01-02 17:48:02.753682	f
64	514300328	annabellis7	2026-01-02 17:56:43.136138	2026-01-02 17:56:43.136156	f
65	8401623498	platega_julia	2026-01-03 15:59:26.083327	2026-01-03 15:59:26.083336	f
66	8341832184	\N	2026-01-03 16:17:17.717192	2026-01-03 16:17:17.7172	f
67	7108317408	aaandrey23	2026-01-03 16:54:17.532004	2026-01-03 16:54:17.53201	f
\.


--
-- Name: admin_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admin_sessions_id_seq', 1, false);


--
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.admins_id_seq', 1, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 83, true);


--
-- Name: crossposting_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.crossposting_links_id_seq', 72, true);


--
-- Name: failed_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.failed_messages_id_seq', 39, true);


--
-- Name: max_channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.max_channels_id_seq', 72, true);


--
-- Name: messages_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_log_id_seq', 1286, true);


--
-- Name: telegram_channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.telegram_channels_id_seq', 62, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 67, true);


--
-- Name: admin_sessions admin_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT admin_sessions_pkey PRIMARY KEY (id);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: crossposting_links crossposting_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crossposting_links
    ADD CONSTRAINT crossposting_links_pkey PRIMARY KEY (id);


--
-- Name: failed_messages failed_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_messages
    ADD CONSTRAINT failed_messages_pkey PRIMARY KEY (id);


--
-- Name: max_channels max_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.max_channels
    ADD CONSTRAINT max_channels_pkey PRIMARY KEY (id);


--
-- Name: messages_log messages_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages_log
    ADD CONSTRAINT messages_log_pkey PRIMARY KEY (id);


--
-- Name: telegram_channels telegram_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_channels
    ADD CONSTRAINT telegram_channels_pkey PRIMARY KEY (id);


--
-- Name: messages_log uq_link_message; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages_log
    ADD CONSTRAINT uq_link_message UNIQUE (crossposting_link_id, telegram_message_id);


--
-- Name: crossposting_links uq_telegram_max_channels; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crossposting_links
    ADD CONSTRAINT uq_telegram_max_channels UNIQUE (telegram_channel_id, max_channel_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_action_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_action_created ON public.audit_log USING btree (action, created_at);


--
-- Name: idx_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_created_at ON public.messages_log USING btree (created_at);


--
-- Name: idx_is_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_is_enabled ON public.crossposting_links USING btree (is_enabled);


--
-- Name: idx_link_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_link_created ON public.messages_log USING btree (crossposting_link_id, created_at);


--
-- Name: idx_max_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_max_channel ON public.crossposting_links USING btree (max_channel_id);


--
-- Name: idx_retry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_retry ON public.failed_messages USING btree (retry_count, last_retry_at);


--
-- Name: idx_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_status ON public.messages_log USING btree (status);


--
-- Name: idx_subscription_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_status ON public.crossposting_links USING btree (subscription_status);


--
-- Name: idx_telegram_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_telegram_channel ON public.crossposting_links USING btree (telegram_channel_id);


--
-- Name: idx_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_created ON public.audit_log USING btree (user_id, created_at);


--
-- Name: idx_users_is_vip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_is_vip ON public.users USING btree (is_vip);


--
-- Name: ix_admin_sessions_admin_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_admin_sessions_admin_id ON public.admin_sessions USING btree (admin_id);


--
-- Name: ix_admin_sessions_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_admin_sessions_expires_at ON public.admin_sessions USING btree (expires_at);


--
-- Name: ix_admin_sessions_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_admin_sessions_id ON public.admin_sessions USING btree (id);


--
-- Name: ix_admin_sessions_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_admin_sessions_token ON public.admin_sessions USING btree (token);


--
-- Name: ix_admins_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_admins_id ON public.admins USING btree (id);


--
-- Name: ix_admins_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_admins_is_active ON public.admins USING btree (is_active);


--
-- Name: ix_admins_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_admins_username ON public.admins USING btree (username);


--
-- Name: ix_audit_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_created_at ON public.audit_log USING btree (created_at);


--
-- Name: ix_audit_log_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_id ON public.audit_log USING btree (id);


--
-- Name: ix_audit_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_audit_log_user_id ON public.audit_log USING btree (user_id);


--
-- Name: ix_crossposting_links_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crossposting_links_id ON public.crossposting_links USING btree (id);


--
-- Name: ix_crossposting_links_is_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crossposting_links_is_enabled ON public.crossposting_links USING btree (is_enabled);


--
-- Name: ix_crossposting_links_max_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crossposting_links_max_channel_id ON public.crossposting_links USING btree (max_channel_id);


--
-- Name: ix_crossposting_links_telegram_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crossposting_links_telegram_channel_id ON public.crossposting_links USING btree (telegram_channel_id);


--
-- Name: ix_crossposting_links_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_crossposting_links_user_id ON public.crossposting_links USING btree (user_id);


--
-- Name: ix_failed_messages_crossposting_link_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_failed_messages_crossposting_link_id ON public.failed_messages USING btree (crossposting_link_id);


--
-- Name: ix_failed_messages_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_failed_messages_id ON public.failed_messages USING btree (id);


--
-- Name: ix_failed_messages_resolved_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_failed_messages_resolved_at ON public.failed_messages USING btree (resolved_at);


--
-- Name: ix_max_channels_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_max_channels_channel_id ON public.max_channels USING btree (channel_id);


--
-- Name: ix_max_channels_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_max_channels_id ON public.max_channels USING btree (id);


--
-- Name: ix_max_channels_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_max_channels_user_id ON public.max_channels USING btree (user_id);


--
-- Name: ix_messages_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_messages_log_created_at ON public.messages_log USING btree (created_at);


--
-- Name: ix_messages_log_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_messages_log_id ON public.messages_log USING btree (id);


--
-- Name: ix_messages_log_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_messages_log_status ON public.messages_log USING btree (status);


--
-- Name: ix_messages_log_telegram_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_messages_log_telegram_message_id ON public.messages_log USING btree (telegram_message_id);


--
-- Name: ix_telegram_channels_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_telegram_channels_channel_id ON public.telegram_channels USING btree (channel_id);


--
-- Name: ix_telegram_channels_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_telegram_channels_id ON public.telegram_channels USING btree (id);


--
-- Name: ix_telegram_channels_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_telegram_channels_user_id ON public.telegram_channels USING btree (user_id);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_telegram_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_telegram_user_id ON public.users USING btree (telegram_user_id);


--
-- Name: admin_sessions admin_sessions_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_sessions
    ADD CONSTRAINT admin_sessions_admin_id_fkey FOREIGN KEY (admin_id) REFERENCES public.admins(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: crossposting_links crossposting_links_max_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crossposting_links
    ADD CONSTRAINT crossposting_links_max_channel_id_fkey FOREIGN KEY (max_channel_id) REFERENCES public.max_channels(id) ON DELETE CASCADE;


--
-- Name: crossposting_links crossposting_links_telegram_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crossposting_links
    ADD CONSTRAINT crossposting_links_telegram_channel_id_fkey FOREIGN KEY (telegram_channel_id) REFERENCES public.telegram_channels(id) ON DELETE CASCADE;


--
-- Name: crossposting_links crossposting_links_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.crossposting_links
    ADD CONSTRAINT crossposting_links_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: failed_messages failed_messages_crossposting_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_messages
    ADD CONSTRAINT failed_messages_crossposting_link_id_fkey FOREIGN KEY (crossposting_link_id) REFERENCES public.crossposting_links(id) ON DELETE CASCADE;


--
-- Name: max_channels max_channels_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.max_channels
    ADD CONSTRAINT max_channels_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages_log messages_log_crossposting_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages_log
    ADD CONSTRAINT messages_log_crossposting_link_id_fkey FOREIGN KEY (crossposting_link_id) REFERENCES public.crossposting_links(id) ON DELETE CASCADE;


--
-- Name: telegram_channels telegram_channels_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.telegram_channels
    ADD CONSTRAINT telegram_channels_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict y548af1VOusN5pGEb4O8Eddv4yvPkkIq9BYu78XSAAnsuPbfOhYBqo4WDFBNEyl

